# Main Chat Integration Guide

## Purpose

This guide shows how to use the bundle inside the normal working process without turning the main chat into a vague universal prompt workspace.

## Recommended Pattern

### 1. Use the Meta Control Plane first
When the request is about prompt work, start with:
- `meta_prompt_control_plane_v2`
- let it classify the task
- let it choose one primary family

### 2. Route to exactly one family
Never skip directly to a family prompt unless the task is already pre-classified and low-risk.

### 3. Run the validator for sensitive cases
Mandatory when:
- runtime behavior is involved
- authoritative surfaces are touched
- worker generation is requested
- migration is requested
- hidden authority drift risk is medium/high

### 4. Validate the artifact against the shared contract
Do not treat a prompt as production-ready if:
- required fields are missing
- failure behavior is missing
- escalation rules are missing
- role drift is present
- deterministic override is implied

## Operational Embedding

### Main chat
Use main chat for:
- project context intake
- problem framing
- requesting one prompt artifact at a time
- reviewing output
- deciding whether to approve, revise, or migrate

### Artifact generation
Use the prompt family selected by the control plane to produce exactly one primary artifact.

### Release / storage
Store only artifacts that:
- passed shared contract validation
- passed boundary validation where required
- have explicit release approval

## Anti-Patterns

Do not:
- ask the Architect to generate runtime workers directly
- use Review when the real task is Migration
- use a Skill prompt for runtime-triggered behavior
- let a Worker artifact omit escalation or failure behavior
- accept prose-only output for production-governed artifacts

## Suggested Team Workflow

1. intake request in main chat
2. run control plane decision
3. inspect selected family
4. generate artifact
5. run validator if required
6. validate contract completeness
7. approve / revise / block

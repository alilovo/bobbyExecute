# Bundle Definition

## What is included

### 1. Contract
- `shared_prompt_contract_v2.json`
- canonical required fields, authority levels, and global rules

### 2. Router
- `prompt_type_router_v2.prompt.md`
- `prompt_type_router_v2.schema.json`
- classifies one primary intent and one primary prompt family

### 3. Boundary Guard
- `boundary_authority_validator_v1.prompt.md`
- `boundary_authority_validator_v1.schema.json`
- validates authority alignment, role drift, deterministic override risk, and release readiness

### 4. Meta Control Plane
- `meta_prompt_control_plane_v2.prompt.md`
- `meta_prompt_control_plane_v2.schema.json`
- orchestrates routing, validation, artifact generation, and release state

### 5. Prompt Families
- `master_prompt_architect_v2`
- `prompt_review_audit_v2`
- `prompt_migration_v2`
- `skill_prompt_generator_v2`
- `function_worker_prompt_generator_v2`

Each family includes:
- one prompt file
- one output schema

### 6. Example Requests
Four example request payloads for:
- review
- migration
- skill generation
- worker generation

### 7. Workflow Guides
- main-chat integration guide
- production usage notes
- release checklist

## Intended Use

This bundle is meant to be mounted as the governance layer for prompt work inside a project.
It is not a generic creative prompt set.
It is a control plane for producing bounded prompt artifacts safely.

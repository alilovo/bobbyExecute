# BobbyExecute — Event / Gate / State / Journal Spec v1

## Status
Draft v1 — high-detail architecture specification for event-driven Low Cap Hunter and Shadow Intelligence workers, aligned to:
- deterministic authority remains sole execution authority
- model calls are promotion-gated
- every trigger, suppression, and model invocation is journaled
- no model output may directly trigger execution

---

# 1. Purpose

This specification defines the event-driven worker architecture for:
- **Low Cap Hunter**
- **Shadow Intelligence**

It formalizes:
- event types
- gate rules
- state machines
- cooldown / dedupe keys
- model-routing rules
- journal fields

The objective is to ensure that:
- cheap deterministic detection runs continuously
- expensive model calls happen only on promoted events
- events are replayable and audit-friendly
- authority boundaries remain explicit and fail-closed

---

# 2. Scope and Non-Goals

## In scope
- event detection
- promotion and suppression logic
- candidate/watchlist state transitions
- model routing for event adjudication
- journaling requirements for all high-value decisions
- batching, dedupe, and cooldown discipline

## Out of scope
- direct trade execution authority
- risk/governance mutation authority
- signer/control integration
- silent self-modifying optimization
- unbounded generic orchestration tools

---

# 3. Architectural Thesis

The system must operate in this order:

```text
ingest
→ normalize
→ deterministic feature extraction
→ event detection
→ gate evaluation
→ dedupe/cooldown/batch checks
→ optional model call
→ normalized assessment
→ journal
→ watchlist/case/review updates
```

Hard rule:

```text
event triggers model
≠
model triggers execution
```

Instead:

```text
event
→ model summary / assessment
→ journal / watchlist / review signal
→ deterministic core remains authority
```

---

# 4. Worker Roles

## 4.1 Meta Fetch
Scheduled worker.
Not governed by this spec except as an upstream producer of:
- watchlist baselines
- meta snapshots
- narrative observations
- account / KOL tiers
- context packs

## 4.2 Low Cap Hunter
Event-driven candidate promotion worker.
Focus:
- early-stage launch / low-cap opportunity detection
- fast emergence / acceleration windows
- early narrative/onchain convergence

## 4.3 Shadow Intelligence
Event-driven state-monitor worker.
Focus:
- watchlist monitoring
- thesis drift
- state transitions
- risk spikes
- contradiction / anomaly compression
- review-oriented intelligence updates

---

# 5. Event Type Taxonomy

## 5.1 Shared Event Envelope

Every emitted event must conform to this logical envelope:

- `event_id`
- `event_type`
- `event_family`
- `event_version`
- `producer`
- `entity_type`
- `entity_id`
- `entity_key`
- `observed_at`
- `window_start`
- `window_end`
- `severity`
- `confidence`
- `knowledge_mode`
- `evidence_refs[]`
- `feature_snapshot`
- `promotion_candidate`
- `suppression_candidate`
- `trace_id`
- `source_scope`

## 5.2 Low Cap Hunter Event Types

### Observation-level
- `lowcap.token_observed`
- `lowcap.launch_detected`
- `lowcap.bonding_state_changed`
- `lowcap.first_liquidity_seen`
- `lowcap.first_volume_spike`
- `lowcap.first_holder_acceleration`
- `lowcap.first_trusted_mention`

### Candidate-level
- `lowcap.candidate_screened`
- `lowcap.candidate_scored`
- `lowcap.candidate_convergence_detected`
- `lowcap.candidate_integrity_checked`
- `lowcap.candidate_watchlist_eligible`

### Promotion-level
- `lowcap.candidate_promoted`
- `lowcap.candidate_promoted_high_priority`
- `lowcap.candidate_borderline`
- `lowcap.candidate_batched_for_review`

### Suppression / rejection
- `lowcap.candidate_suppressed_cooldown`
- `lowcap.candidate_suppressed_dedupe`
- `lowcap.candidate_suppressed_integrity`
- `lowcap.candidate_rejected_toxicity`
- `lowcap.candidate_rejected_distribution`
- `lowcap.candidate_rejected_staleness`
- `lowcap.candidate_rejected_no_convergence`

### Post-model
- `lowcap.model_assessment_completed`
- `lowcap.model_assessment_inconclusive`
- `lowcap.watchlist_added`
- `lowcap.watchlist_rejected`
- `lowcap.review_queue_added`

## 5.3 Shadow Intelligence Event Types

### Observation-level
- `shadow.watch_observed`
- `shadow.watch_metric_delta`
- `shadow.attention_velocity_changed`
- `shadow.onchain_integrity_changed`
- `shadow.kol_signal_changed`
- `shadow.liquidity_state_changed`
- `shadow.distribution_state_changed`

### Transition-level
- `shadow.transition_candidate`
- `shadow.transition_detected`
- `shadow.transition_confirmed`
- `shadow.thesis_conflict_detected`
- `shadow.risk_spike_detected`
- `shadow.attention_collapse_detected`
- `shadow.expansion_detected`
- `shadow.exhaustion_risk_detected`
- `shadow.invalidated_detected`

### Suppression / control
- `shadow.transition_suppressed_cooldown`
- `shadow.transition_suppressed_dedupe`
- `shadow.transition_suppressed_low_severity`
- `shadow.transition_batched`
- `shadow.transition_deferred`

### Post-model
- `shadow.model_assessment_completed`
- `shadow.case_update_required`
- `shadow.watch_state_updated`
- `shadow.review_queue_added`
- `shadow.operator_attention_required`

---

# 6. Gate Rules

## 6.1 Gate Classes

Every event must pass through these gate classes in order:

1. **Validity Gate**
2. **Integrity Gate**
3. **Convergence / Relevance Gate**
4. **Dedupe Gate**
5. **Cooldown Gate**
6. **Batch / Debounce Gate**
7. **Model Promotion Gate**
8. **Post-Model Routing Gate**

## 6.2 Validity Gate

Purpose:
ensure minimum data completeness and time-window sanity.

Required checks:
- entity identity present
- required feature fields present
- event window sane
- event timestamp not corrupt
- no impossible negative metrics
- source provenance available
- event family supported by schema version

Failure action:
- suppress event
- emit `*.suppressed_invalid`
- journal suppression reason

## 6.3 Integrity Gate

Purpose:
block candidates/transitions that should not proceed because foundational quality is poor.

Typical checks:
- liquidity not critically weak
- holder integrity above minimum
- toxicity not above hard threshold
- distribution concentration not blocker-level
- source confidence above minimum
- known bad pattern / denylist not triggered

Failure action:
- reject candidate
- do not model-call
- journal reason class + evidence

## 6.4 Convergence / Relevance Gate

Purpose:
ensure only meaningful events progress.

Low Cap Hunter examples:
- market cap within configured band
- attention velocity above threshold
- holder growth above threshold
- volume acceleration above threshold
- trusted mention or account-cluster support
- novelty / freshness still acceptable

Shadow examples:
- state delta exceeds transition threshold
- thesis conflict is material, not cosmetic
- risk spike exceeds minimum severity
- watchlist token is still active / relevant
- shift is not just single-source noise

Failure action:
- do not promote
- either journal-only or batch-only
- optionally keep watch state unchanged

## 6.5 Dedupe Gate

Purpose:
suppress repeated equivalent events inside a defined key window.

Logic:
- compute dedupe key
- compare with active dedupe registry
- if same entity/event family/time bucket already handled, suppress

Action on hit:
- emit `*.suppressed_dedupe`
- journal original event reference

## 6.6 Cooldown Gate

Purpose:
prevent repeated model invocations for the same entity/type within a configured cooldown window.

Logic:
- lookup latest handled event by cooldown key
- if within cooldown and severity has not escalated enough, suppress
- if severity significantly escalated, allow override

Action on hit:
- emit `*.suppressed_cooldown`
- journal blocked call reason

## 6.7 Batch / Debounce Gate

Purpose:
prefer short collection windows over immediate per-event model calls.

Default pattern:
- hold events 2–5 minutes
- group by entity or cluster
- summarize multiple weak signals into one stronger promotion candidate

Action:
- either hold
- batch
- or release to model gate

## 6.8 Model Promotion Gate

Purpose:
decide whether an event warrants a model call.

Promotion conditions must require one or more of:
- high severity
- meaningful convergence
- genuine ambiguity needing adjudication
- major state transition
- review significance
- operator attention significance

Non-promotion actions:
- journal-only
- watchlist update without model
- batch for later review
- drop as non-material

---

# 7. State Machines

## 7.1 Low Cap Hunter State Machine

```text
observed
→ screened
→ candidate
→ promoted
→ modeled
→ watchlisted / rejected / review_queue
```

### States

#### `observed`
token/event seen but not screened.

Entry:
- new token observed
- launch / bonding / liquidity / attention event seen

Exit:
- feature extraction complete

#### `screened`
basic deterministic screens applied.

Exit conditions:
- pass → `candidate`
- fail → `rejected`

#### `candidate`
valid opportunity candidate exists.

Exit conditions:
- enough quality + relevance → `promoted`
- not enough → `rejected` or remain `candidate`

#### `promoted`
eligible for expensive adjudication.

Exit conditions:
- model gate pass → `modeled`
- cooldown/dedupe/batch hold → remain pending

#### `modeled`
model assessment attached.

Exit conditions:
- strong positive assessment → `watchlisted`
- inconclusive → `review_queue`
- negative → `rejected`

#### `watchlisted`
now tracked by Shadow or other monitoring layers.

#### `rejected`
not worthy of further escalation.

#### `review_queue`
requires operator or later batch review.

## 7.2 Shadow Intelligence State Machine

```text
watching
→ stable
→ notable_change
→ transition_detected
→ modeled
→ updated_case / review_queue / alert
```

### States

#### `watching`
entity is under observation.

#### `stable`
no meaningful transition.

#### `notable_change`
measurable delta observed but not yet promotion-worthy.

#### `transition_detected`
threshold for material change crossed.

#### `modeled`
model assessment completed for transition or conflict.

#### `updated_case`
casebook / watch-state / thesis updated.

#### `review_queue`
needs operator review.

#### `alert`
high-severity attention required.

---

# 8. Cooldown / Dedupe Keys

## 8.1 Design Rules

Keys must:
- be deterministic
- be short enough for storage/indexing
- separate event family from entity
- separate coarse time bucket from raw timestamp
- support severity override rules

## 8.2 Dedupe Key Templates

### Low Cap Hunter
```text
lowcap:{token_id}:{event_family}:{time_bucket}
```

Example:
```text
lowcap:So111...:candidate_promoted:2026-04-06T14:00Z/15m
```

### Shadow
```text
shadow:{entity_id}:{transition_type}:{time_bucket}
```

Example:
```text
shadow:token_xyz:exhaustion_risk:2026-04-06T16:00Z/30m
```

## 8.3 Cooldown Key Templates

### Low Cap Hunter
```text
lowcap_cd:{token_id}:{promotion_class}
```

Example cooldown windows:
- borderline candidate: 30m
- promoted candidate: 45m
- high-priority promoted: 15m override possible

### Shadow
```text
shadow_cd:{entity_id}:{transition_class}
```

Example cooldown windows:
- normal transition: 60m
- thesis conflict: 30m
- critical risk spike: 15m with escalation override

## 8.4 Severity Override Rule

Cooldown may be bypassed only when:
- severity class increases by defined step
- evidence class materially changes
- new source family appears
- transition type changes category

This override must be journaled.

---

# 9. Model-Routing Rules

## 9.1 Routing Principles

Models are used only for:
- semantic compression
- conflict adjudication
- explanation
- ambiguity handling
- review-ready summaries
- structured assessment generation

Models are not used for:
- direct execution decisions
- control mutations
- signer actions
- canonical decision ownership
- final risk authority

## 9.2 Route Classes

### Route A — No Model
Use when:
- deterministic evidence is sufficient
- event is low severity
- event is duplicate/stale
- event is only useful for journaling

### Route B — Small Model / Cheap Adjudication
Use when:
- borderline classification
- weak ambiguity
- structured summarization needed
- event frequency is high

Typical outputs:
- normalized label
- relevance score
- short assessment
- batch summary

### Route C — High-Quality Model / Deep Adjudication
Use when:
- high-value promoted candidate
- material thesis conflict
- significant watchlist transition
- review-significant event
- contradictory evidence needs synthesis

Typical outputs:
- structured assessment pack
- contradiction summary
- promotion rationale
- watchlist / review recommendation
- limitations and confidence flags

## 9.3 Route Triggers — Low Cap Hunter

High-quality model allowed only if:
- candidate promoted
- integrity pass
- convergence above threshold
- freshness acceptable
- not blocked by dedupe/cooldown
- candidate is actually watchlist-worthy or decision-relevant

Cheap model allowed for:
- borderline candidate triage
- multi-candidate batch ranking
- semantic clustering of similar weak signals

## 9.4 Route Triggers — Shadow

High-quality model allowed only if:
- transition confirmed
- thesis conflict detected
- high-severity anomaly
- review/case significance high

Cheap model allowed for:
- low-stakes transition labeling
- routine watchlist change summarization
- batch digest for multiple watch entities

## 9.5 Required Model Output Envelope

Every model result must return a normalized envelope:

- `assessment_id`
- `route_class`
- `model_provider`
- `model_name`
- `requested_at`
- `completed_at`
- `entity_type`
- `entity_id`
- `input_context_ref`
- `assessment_label`
- `assessment_summary`
- `confidence`
- `limitations[]`
- `evidence_refs[]`
- `recommendation_type`
- `recommendation_target`
- `non_authority_notice`
- `trace_id`

Mandatory notice:
model result is advisory / compressive only and does not constitute execution authority.

---

# 10. Journal Fields

## 10.1 Journaling Principles

Journal:
- every emitted event
- every suppression
- every promotion
- every model route decision
- every model call
- every model result
- every watchlist/case/review write resulting from the event

## 10.2 Event Journal Record

Required fields:
- `journal_event_id`
- `trace_id`
- `event_id`
- `event_type`
- `event_family`
- `event_version`
- `producer`
- `worker_name`
- `entity_type`
- `entity_id`
- `entity_key`
- `observed_at`
- `ingested_at`
- `window_start`
- `window_end`
- `severity`
- `confidence`
- `knowledge_mode`
- `source_scope`
- `feature_snapshot`
- `evidence_refs[]`
- `raw_payload_ref`
- `journal_status`

## 10.3 Gate Evaluation Journal Record

Required fields:
- `gate_eval_id`
- `trace_id`
- `event_id`
- `gate_name`
- `gate_result` = pass | fail | suppress | defer | batch
- `gate_reason_class`
- `gate_reason_code`
- `threshold_snapshot`
- `dedupe_key`
- `cooldown_key`
- `prior_event_ref`
- `severity_override_used`
- `evaluated_at`

## 10.4 Model Routing Journal Record

Required fields:
- `route_decision_id`
- `trace_id`
- `event_id`
- `route_class`
- `route_reason`
- `model_provider`
- `model_name`
- `context_pack_ref`
- `input_token_estimate`
- `priority_class`
- `cooldown_override`
- `requested_at`

## 10.5 Model Result Journal Record

Required fields:
- `assessment_id`
- `trace_id`
- `event_id`
- `model_provider`
- `model_name`
- `response_latency_ms`
- `input_tokens`
- `output_tokens`
- `assessment_label`
- `assessment_summary`
- `confidence`
- `limitations[]`
- `evidence_refs[]`
- `recommendation_type`
- `recommendation_target`
- `non_authority_notice`
- `completed_at`

## 10.6 Suppression Journal Record

Required fields:
- `suppression_id`
- `trace_id`
- `event_id`
- `suppression_type` = invalid | dedupe | cooldown | integrity | low_relevance | stale | denied
- `suppression_reason`
- `suppression_reason_class`
- `dedupe_key`
- `cooldown_key`
- `blocking_evidence_refs[]`
- `suppressed_at`

## 10.7 Resulting Write Journal Record

Required fields:
- `write_effect_id`
- `trace_id`
- `source_event_id`
- `effect_type` = watchlist_add | watchlist_update | case_update | review_queue_add | no_write
- `target_ref`
- `write_reason`
- `written_at`

---

# 11. Recommended Defaults

## 11.1 Debounce Windows
- Low Cap Hunter: 2–5 minutes
- Shadow: 3–10 minutes

## 11.2 Cooldowns
- Low Cap Hunter promoted candidate: 30–45 minutes
- Shadow normal transition: 60 minutes
- Critical anomaly: 15 minutes with override path

## 11.3 Batch Preferences
Prefer:
- batch ranking of similar low-value candidates
- batch digest for multiple Shadow transitions
Avoid:
- repeated deep-model calls per near-identical event

---

# 12. Acceptance Criteria

This architecture is acceptable only if all of the following are true:

1. Every model call is preceded by explicit promotion logic.
2. Every suppression reason is journaled.
3. Dedupe and cooldown keys are deterministic and replayable.
4. Low Cap Hunter and Shadow state transitions are explicit.
5. Model outputs are advisory and normalized.
6. No event path bypasses the deterministic authority boundary.
7. The same event can be reconstructed from journal records.
8. Borderline or high-frequency cases can be batched instead of deep-called.
9. Watchlist/case/review writes are trace-linked to source events.
10. No model output directly mutates execution authority.

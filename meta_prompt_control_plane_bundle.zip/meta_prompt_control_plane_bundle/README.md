# Meta Prompt Control Plane — Production Bundle

This bundle packages a production-ready prompt governance system for building, reviewing, migrating, and routing prompt artifacts inside a structured project.

## Bundle Goals

- enforce a shared prompt contract
- route requests to exactly one primary prompt family
- validate boundary and authority safety before release
- keep architect / review / migration / skill / worker roles strictly separated
- provide machine-checkable output schemas and example requests

## Core Components

1. `shared_prompt_contract_v2`
2. `prompt_type_router_v2`
3. `boundary_authority_validator_v1`
4. `meta_prompt_control_plane_v2`
5. `master_prompt_architect_v2`
6. `prompt_review_audit_v2`
7. `prompt_migration_v2`
8. `skill_prompt_generator_v2`
9. `function_worker_prompt_generator_v2`

## Recommended Operating Order

1. intake request
2. apply control plane
3. router selects exactly one primary family
4. validator runs for sensitive cases
5. selected family generates or reviews one artifact
6. shared contract validation checks completeness
7. optional governance audit runs when unresolved risk remains

## Production Notes

This bundle includes:
- prompt files (`*.prompt.md`)
- machine-readable output schemas (`*.schema.json`)
- example request payloads
- workflow integration guidance for main chat / orchestration usage

## Constraints

- no prompt artifact may bypass the shared contract
- no prompt may silently replace deterministic logic
- skill and worker roles must remain separate
- review and migration roles must remain separate
- production-sensitive artifacts should prefer `strict_json`

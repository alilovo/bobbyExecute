# Production Usage Notes

## Default Output Modes
- `strict_json` for production-governed prompt artifacts
- `audit_format` for review
- `migration_format` for migration
- `structured` for architecture mapping
- `prose` only for explanatory meta summaries, never for production-governed artifacts

## Hard Fail Conditions
- deterministic override detected
- worker controller drift detected
- high-severity authority drift detected
- missing failure behavior on sensitive artifact
- missing escalation rules on sensitive artifact

## Release Rule
An artifact may be generated but still not be release-approved.
Track both:
- artifact generation status
- release approval status

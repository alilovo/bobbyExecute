# Release Checklist

Before treating any artifact as production-ready, confirm:

- [ ] shared prompt contract applied
- [ ] contract name + version present
- [ ] known_context separated from assumed_context
- [ ] one primary prompt family only
- [ ] authority level valid
- [ ] allowed_actions present
- [ ] forbidden_actions present
- [ ] decision_constraints present
- [ ] escalation_rules present
- [ ] failure_behavior present
- [ ] no role drift
- [ ] no deterministic override
- [ ] validator run for sensitive cases
- [ ] release_state.release_approved is true
